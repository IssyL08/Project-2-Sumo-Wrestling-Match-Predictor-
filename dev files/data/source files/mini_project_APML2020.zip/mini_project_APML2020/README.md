# mini_project_APML2020
Gibbs sampling and message passing to predict Serie A and Sumo wrestler results

To run: 
Place the files from this repository in the same folder and run the ipynb notebook. 

Contributors: Max Sonebäck, Olle Kåhre Zäll, Kevin Ajamlou, Olle Dahlstedt
